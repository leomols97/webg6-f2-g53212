package g53212.webg6.pae;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaeApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaeApplication.class, args);
	}

}
